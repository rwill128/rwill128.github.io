# Clean-room reproduction input v1

This archive is the isolated specification input. It contains only this README, the method specification, public-source pins, reported results, and a byte manifest. It does not contain the author search implementation, author-generated traces, patches, custom verification scripts, vendor checkouts, or saved reproduction outputs.

An independent reproducer should obtain the two public repositories directly from the links in `SOURCE_PINS.json`, implement the method described in `METHOD_SPEC.md`, and compare its results with `REPORTED_RESULTS.json`. The full author review bundle should remain unavailable to that reproducer until it has frozen its implementation and results.

The reported result is compiler/simulator evidence for a pinned Clifford-only compiler. It is not hardware evidence and not a Shor result. The reported-results file includes the observed numerical-platform boundary; an independent implementation should report whether each effect survives its own platform rather than forcing exact agreement.
