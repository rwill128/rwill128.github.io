# CircLS orientation-search reproduction companion v1.4

The normative, self-contained reproduction method is the public article:

<https://rwill128.github.io/writing/circls-orientation-clean-room/>

This archive is optional. It duplicates public inputs and reported numbers in
machine-readable form so a reproducer can check transcription without treating
the archive as an implementation.

## Files

- `METHOD_SPEC.md`: plain-text copy of the article's search and verification
  method.
- `SOURCE_PINS.json`: exact public repository revisions.
- `BENCHMARKS.json`: exact constructors, input sizes, and QASM hashes.
- `REQUIREMENTS.lock`: original Python package versions.
- `REPORTED_RESULTS.json`: the results to compare only after freezing an
  independent implementation and run record.
- `MANIFEST.sha256`: content hashes for this directory, excluding the manifest
  itself.

## Clean-room boundary

Implement the search from the public article and the pinned CircLS and
QASMBench repositories. Before opening `REPORTED_RESULTS.json`, freeze the
implementation, environment and BLAS/LAPACK identity, generated QASM hashes,
commands, source archive, raw outputs, and commit hashes.

This archive contains no author search implementation, generated trace, frozen
placement, final orientation map, custom verifier, or saved reproduction
output. The released CircLS verifier is part of the pinned public dependency,
not an author-supplied replacement.

Independent reproduction count at publication: **zero**.
